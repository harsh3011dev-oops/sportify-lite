import React, { createContext, useContext, useState, useEffect, useRef, useMemo } from 'react';
import { Track, Album, Artist, Playlist, RepeatMode, ViewType, ViewParams } from '../types/music';
import { MOCK_TRACKS, MOCK_PLAYLISTS, getAlbumById, getArtistById } from '../data/mockData';

interface MusicPlayerContextType {
  // Playback state
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  queue: Track[];
  history: Track[];
  likedSongIds: Set<string>;

  // Playback actions
  playTrack: (track: Track, newQueue?: Track[]) => void;
  togglePlay: () => void;
  pause: () => void;
  nextTrack: () => void;
  prevTrack: () => void;
  seekTo: (seconds: number) => void;
  setVolumeLevel: (level: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  toggleLike: (trackId: string) => void;
  isLiked: (trackId: string) => boolean;

  // Queue actions
  addToQueue: (track: Track) => void;
  removeFromQueue: (trackId: string) => void;
  clearQueue: () => void;

  // Navigation state & actions
  currentView: ViewType;
  viewParams: ViewParams;
  navigateTo: (view: ViewType, params?: ViewParams) => void;
  navigateBack: () => void;
  navigateForward: () => void;
  canNavigateBack: boolean;
  canNavigateForward: boolean;

  // UI state
  isNowPlayingOpen: boolean;
  toggleNowPlaying: () => void;
  isQueueModalOpen: boolean;
  toggleQueueModal: () => void;
  isFullScreenPlayerOpen: boolean;
  toggleFullScreenPlayer: () => void;
  isExportModalOpen: boolean;
  setExportModalOpen: (open: boolean) => void;
}

const MusicPlayerContext = createContext<MusicPlayerContextType | null>(null);

export const MusicPlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation stack
  const [navHistory, setNavHistory] = useState<{ view: ViewType; params: ViewParams }[]>([
    { view: 'home', params: {} }
  ]);
  const [navIndex, setNavIndex] = useState(0);

  // Playback state
  const [currentTrack, setCurrentTrack] = useState<Track | null>(MOCK_TRACKS[0]); // Start with a default track ready to explore
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(MOCK_TRACKS[0].duration);
  const [volume, setVolume] = useState<number>(0.8);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [queue, setQueue] = useState<Track[]>(MOCK_TRACKS.slice(1));
  const [history, setHistory] = useState<Track[]>([]);
  const [likedSongIds, setLikedSongIds] = useState<Set<string>>(() => {
    // Initial liked songs
    return new Set(['track-1', 'track-2', 'track-4', 'track-7']);
  });

  // UI Panels
  const [isNowPlayingOpen, setIsNowPlayingOpen] = useState<boolean>(false);
  const [isQueueModalOpen, setIsQueueModalOpen] = useState<boolean>(false);
  const [isFullScreenPlayerOpen, setIsFullScreenPlayerOpen] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Timer reference for simulated audio scrubbing & Web Audio synth
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Stop web audio synthesis helper
  const stopWebAudio = () => {
    try {
      if (oscillatorRef.current) {
        oscillatorRef.current.stop();
        oscillatorRef.current.disconnect();
        oscillatorRef.current = null;
      }
    } catch {
      // Ignored
    }
  };

  // Start pleasant ambient synth tone to accompany playback if user interacts
  const startWebAudio = () => {
    try {
      if (!audioContextRef.current) {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          audioContextRef.current = new AudioCtx();
        }
      }

      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
      }

      if (audioContextRef.current && !oscillatorRef.current) {
        const ctx = audioContextRef.current;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const filter = ctx.createBiquadFilter();

        osc.type = 'sine';
        // Warm subtle fundamental chord frequency (e.g. 110Hz A2)
        osc.frequency.setValueAtTime(110, ctx.currentTime);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, ctx.currentTime);

        // Very quiet, gentle ambient warmth
        const effectiveVol = isMuted ? 0 : volume * 0.05;
        gain.gain.setValueAtTime(effectiveVol, ctx.currentTime);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);

        osc.start();
        oscillatorRef.current = osc;
        gainNodeRef.current = gain;
      }
    } catch {
      // Browsers may restrict autoplay until user gestures, which is standard
    }
  };

  // Update web audio volume when volume changes
  useEffect(() => {
    if (gainNodeRef.current && audioContextRef.current) {
      const effectiveVol = isMuted ? 0 : volume * 0.05;
      gainNodeRef.current.gain.setValueAtTime(effectiveVol, audioContextRef.current.currentTime);
    }
  }, [volume, isMuted]);

  // Playback timer ticker
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      startWebAudio();
      interval = setInterval(() => {
        setCurrentTime((prev) => {
          if (prev >= duration) {
            // End of track reached
            if (repeatMode === 'one') {
              return 0;
            } else {
              nextTrack();
              return 0;
            }
          }
          return prev + 1;
        });
      }, 1000);
    } else {
      stopWebAudio();
    }

    return () => {
      clearInterval(interval);
      stopWebAudio();
    };
  }, [isPlaying, duration, repeatMode]);

  // Current view from history
  const currentNav = navHistory[navIndex] || { view: 'home', params: {} };
  const currentView = currentNav.view;
  const viewParams = currentNav.params;

  const navigateTo = (view: ViewType, params: ViewParams = {}) => {
    const nextHistory = navHistory.slice(0, navIndex + 1);
    nextHistory.push({ view, params });
    setNavHistory(nextHistory);
    setNavIndex(nextHistory.length - 1);
  };

  const navigateBack = () => {
    if (navIndex > 0) {
      setNavIndex((i) => i - 1);
    }
  };

  const navigateForward = () => {
    if (navIndex < navHistory.length - 1) {
      setNavIndex((i) => i + 1);
    }
  };

  const canNavigateBack = navIndex > 0;
  const canNavigateForward = navIndex < navHistory.length - 1;

  // Play a specific track
  const playTrack = (track: Track, newQueue?: Track[]) => {
    if (currentTrack?.id === track.id) {
      setIsPlaying(!isPlaying);
      return;
    }

    if (currentTrack) {
      setHistory((prev) => [currentTrack, ...prev.filter((t) => t.id !== currentTrack.id)].slice(0, 30));
    }

    setCurrentTrack(track);
    setCurrentTime(0);
    setDuration(track.duration);
    setIsPlaying(true);

    if (newQueue) {
      setQueue(newQueue.filter((t) => t.id !== track.id));
    }
  };

  const togglePlay = () => {
    if (!currentTrack && MOCK_TRACKS.length > 0) {
      playTrack(MOCK_TRACKS[0]);
      return;
    }
    setIsPlaying(!isPlaying);
  };

  const pause = () => {
    setIsPlaying(false);
  };

  const nextTrack = () => {
    if (queue.length > 0) {
      let nextIdx = 0;
      if (isShuffle) {
        nextIdx = Math.floor(Math.random() * queue.length);
      }
      const next = queue[nextIdx];
      const remaining = queue.filter((_, idx) => idx !== nextIdx);

      if (currentTrack) {
        setHistory((prev) => [currentTrack, ...prev.filter((t) => t.id !== currentTrack.id)].slice(0, 30));
      }

      setCurrentTrack(next);
      setCurrentTime(0);
      setDuration(next.duration);
      setQueue(remaining);
      setIsPlaying(true);
    } else if (repeatMode === 'all') {
      // Loop back to beginning of all tracks
      if (MOCK_TRACKS.length > 0) {
        const next = MOCK_TRACKS[0];
        setCurrentTrack(next);
        setCurrentTime(0);
        setDuration(next.duration);
        setQueue(MOCK_TRACKS.slice(1));
        setIsPlaying(true);
      }
    } else {
      setIsPlaying(false);
      setCurrentTime(0);
    }
  };

  const prevTrack = () => {
    // If more than 3 seconds into song, restart track
    if (currentTime > 3) {
      setCurrentTime(0);
      return;
    }

    if (history.length > 0) {
      const prev = history[0];
      const newHistory = history.slice(1);

      if (currentTrack) {
        setQueue((q) => [currentTrack, ...q]);
      }

      setCurrentTrack(prev);
      setCurrentTime(0);
      setDuration(prev.duration);
      setHistory(newHistory);
      setIsPlaying(true);
    } else {
      setCurrentTime(0);
    }
  };

  const seekTo = (seconds: number) => {
    const clamped = Math.max(0, Math.min(seconds, duration));
    setCurrentTime(clamped);
  };

  const setVolumeLevel = (level: number) => {
    const clamped = Math.max(0, Math.min(level, 1));
    setVolume(clamped);
    if (clamped > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const toggleShuffle = () => {
    setIsShuffle(!isShuffle);
  };

  const toggleRepeat = () => {
    if (repeatMode === 'off') setRepeatMode('all');
    else if (repeatMode === 'all') setRepeatMode('one');
    else setRepeatMode('off');
  };

  const toggleLike = (trackId: string) => {
    setLikedSongIds((prev) => {
      const next = new Set(prev);
      if (next.has(trackId)) {
        next.delete(trackId);
      } else {
        next.add(trackId);
      }
      return next;
    });
  };

  const isLiked = (trackId: string) => likedSongIds.has(trackId);

  const addToQueue = (track: Track) => {
    setQueue((q) => [...q, track]);
  };

  const removeFromQueue = (trackId: string) => {
    setQueue((q) => q.filter((t) => t.id !== trackId));
  };

  const clearQueue = () => {
    setQueue([]);
  };

  const toggleNowPlaying = () => {
    setIsNowPlayingOpen(!isNowPlayingOpen);
  };

  const toggleQueueModal = () => {
    setIsQueueModalOpen(!isQueueModalOpen);
  };

  const toggleFullScreenPlayer = () => {
    setIsFullScreenPlayerOpen(!isFullScreenPlayerOpen);
  };

  const value = {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    queue,
    history,
    likedSongIds,
    playTrack,
    togglePlay,
    pause,
    nextTrack,
    prevTrack,
    seekTo,
    setVolumeLevel,
    toggleMute,
    toggleShuffle,
    toggleRepeat,
    toggleLike,
    isLiked,
    addToQueue,
    removeFromQueue,
    clearQueue,
    currentView,
    viewParams,
    navigateTo,
    navigateBack,
    navigateForward,
    canNavigateBack,
    canNavigateForward,
    isNowPlayingOpen,
    toggleNowPlaying,
    isQueueModalOpen,
    toggleQueueModal,
    isFullScreenPlayerOpen,
    toggleFullScreenPlayer,
    isExportModalOpen,
    setExportModalOpen: setIsExportModalOpen,
  };

  return (
    <MusicPlayerContext.Provider value={value}>
      {children}
    </MusicPlayerContext.Provider>
  );
};

export const useMusicPlayer = () => {
  const context = useContext(MusicPlayerContext);
  if (!context) {
    throw new Error('useMusicPlayer must be used within a MusicPlayerProvider');
  }
  return context;
};
